document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("toggle");
  const navLinks = document.querySelector(".nav-links");

  toggle.addEventListener("change", () => {
    if (toggle.checked) {
      navLinks.classList.add("active");
    } else {
      navLinks.classList.remove("active");
    }
  });
});